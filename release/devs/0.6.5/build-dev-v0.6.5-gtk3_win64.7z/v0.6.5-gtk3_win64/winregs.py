# -*- coding: utf-8 -*-
import os, sys, time, subprocess, netifaces
from _winreg import *

def get_uninstall_progs():
	reg = ConnectRegistry(None,HKEY_LOCAL_MACHINE)
	key = OpenKey(reg, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")
	list = []
	for i in range(1024):
		try:
			keyname = EnumKey(key, i)
			asubkey = OpenKey(key, keyname)
			val = QueryValueEx(asubkey, "DisplayName")
			print val
			list.append(val)
		except WindowsError:
			pass
	reg.Close()
	return list

""" NETWORK ADAPTER """

def get_networkadapter_guids():
	return netifaces.interfaces()

def get_networkadapterlist_from_netsh():
	string = "netsh.exe interface show interface"
	data = subprocess.check_output("%s" % (string),shell=True)
	data = data.split('\r\n')
	return data

def get_networkadapterlist_from_guids(iface_guids):
	iface_names = ['(unknown)' for i in range(len(iface_guids))]
	mapguids = {}
	reg = ConnectRegistry(None, HKEY_LOCAL_MACHINE)
	key = OpenKey(reg, r'SYSTEM\CurrentControlSet\Control\Network\{4d36e972-e325-11ce-bfc1-08002be10318}')
	for i in range(len(iface_guids)):
		try:
			reg_subkey = OpenKey(key, iface_guids[i] + r'\Connection')
			iface_name = QueryValueEx(reg_subkey, 'Name')[0]
			iface_names[i] = iface_name
			mapguids[iface_name] = '%s' % (iface_guids[i])
		except:
			pass
	print "mapguids = '%s'" % (mapguids)
	data = { "iface_names":iface_names,"mapguids":mapguids }
	reg.Close()
	return data
	#return iface_names

def get_networkadapterlist():
	newlist = []
	list1 = get_networkadapterlist_from_guids(get_networkadapter_guids())["iface_names"]
	list2 = get_networkadapterlist_from_netsh()
	for name in list1:
		for line in list2:
			if line.endswith(name):
				newlist.append(name)
	return newlist

def get_networkadapter_guid(adaptername):
	guids = get_networkadapterlist_from_guids(get_networkadapter_guids())["mapguids"]
	guid = guids[adaptername]
	print "def get_networkadapter_guid: adaptername = '%s' guid = '%s'" % (adaptername,guid)
	return guid
	#return get_networkadapterlist_from_guids(get_networkadapter_guids())["mapguids"][adaptername]

def get_tapadapters(OPENVPN_EXE,INTERFACES):
	if os.path.isfile(OPENVPN_EXE):
		string = '"%s" --show-adapters' % (OPENVPN_EXE)
		TAPADAPTERS = subprocess.check_output("%s" % (string),shell=True)
		TAPADAPTERS = TAPADAPTERS.split('\r\n')
		TAPADAPTERS.pop(0)
		TAP_DEVS = list()
		for line in TAPADAPTERS:
			for INTERFACE in INTERFACES:
				if line.startswith("'%s' {"%(INTERFACE)):
					INTERFACES.remove(INTERFACE)
					TAP_DEVS.append(INTERFACE)
					break
		return { "INTERFACES":INTERFACES,"TAP_DEVS":TAP_DEVS }

def get_interface_infos_from_guid(guid):
	print "winregs: def get_interface_infos_from_guid(%s)" % (guid)
	"""
	winregs.get_interface_infos_from_guid("{XXXXXXXX-YYYY-ZZZZ-AAAA-CCCCDDDDEEEE}")
	return = {
			'AddressType': 0, 'DefaultGateway': [u'192.168.1.1'], 'SubnetMask': [u'255.255.255.0'],
			'NameServer': u'8.8.8.8,8.8.4.4', 'IPAddress': [u'192.168.1.123'], 
			'DhcpServer': u'255.255.255.255', 'DhcpIPAddress': u'0.0.0.0'}, 'DhcpSubnetMask': u'255.0.0.0'
	"""
	values = { "AddressType":False, "DefaultGateway":False, "IPAddress":False, "SubnetMask":False, "NameServer":False, "DhcpIPAddress":False, "DhcpServer":False, "DhcpSubnetMask":False }
	reg = ConnectRegistry(None, HKEY_LOCAL_MACHINE)
	key = OpenKey(reg, r'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\%s' % (guid))
	for keyname,value in values.items():
		try:
			values[keyname] = QueryValueEx(key, keyname)[0]
		except:
			pass
	print "get_interface_infos_from_guid: '%s'" % (values)
	reg.Close()
	return values
