connected.ico
connect.ico
testing.ico
disconnect.ico
disconnect_menu.ico
sync_1.ico
sync_2.ico
sync_3.ico