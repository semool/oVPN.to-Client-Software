

	#imgfile = self.FLAG_IMG[countrycode]
		img = Gtk.Image()
		img.set_from_pixbuf(self.decode_flag(countrycode))
		
		
def myResolver(host,dnssrv): 
	r = dns.resolver.Resolver() 
	r.nameservers = dnssrv 
	answers = r.query(host, 'A') 
	for rdata in answers: 
		return str(rdata)

